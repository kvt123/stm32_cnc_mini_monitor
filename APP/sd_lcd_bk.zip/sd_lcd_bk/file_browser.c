#include "file_browser.h"
#include "sdcard.h"
#include <stdio.h>

// --- BIẾN TOÀN CỤC CỦA UI ---
char file_list[MAX_FILES_TO_LOAD][13];
uint16_t total_files = 0;

uint16_t cursor_pos = 0;
static uint16_t prev_cursor_pos = 0;   // Thêm biến lưu vị trí con trỏ trước đó

UI_State_t current_state = STATE_FILE_LIST;
FRESULT scan_error_code = FR_OK;

// --- HÀM QUÉT THẺ NHỚ & LƯU TÊN FILE ---
void Browser_ScanFiles(void)
{
DIR dir;
FILINFO fno;
total_files = 0;
cursor_pos = 0;
prev_cursor_pos = 0;

_mountSdcard(); 

scan_error_code = f_opendir(&dir, ""); 

if (scan_error_code == FR_OK) 
{
    while (f_readdir(&dir, &fno) == FR_OK && fno.fname[0] != 0) 
    {
        if (!(fno.fattrib & AM_DIR) && !(fno.fattrib & AM_HID)) 
        {
            strncpy(file_list[total_files], fno.fname, 13);
            total_files++;
            if (total_files >= MAX_FILES_TO_LOAD) break; 
        }
    }
    f_closedir(&dir);
}


}

// --- HÀM VẼ 1 DÒNG DANH SÁCH (TỐI ƯU HÓA) ---
static void Draw_ListItem(uint16_t index, uint8_t is_selected)
{
if (index >= total_files) return;

// Tính toán vị trí Y của dòng này trên màn hình hiện tại
uint16_t page_start_index = (cursor_pos / MAX_LINES_PER_PAGE) * MAX_LINES_PER_PAGE;
uint16_t screen_line = index - page_start_index;
uint16_t y_pos = 25 + (screen_line * 20); 

if (is_selected) 
{
    // Vẽ dòng được chọn (Bôi nền xám toàn dòng, chữ vàng)
    ST7789_DrawFilledRectangle(0, y_pos, ST7789_WIDTH, 20, GRAY); 
    ST7789_WriteString(2, y_pos, ">", Font_11x18, YELLOW, GRAY);
    ST7789_WriteString(18, y_pos, file_list[index], Font_11x18, YELLOW, GRAY);
} 
else 
{
    // Xóa sạch nền cũ của dòng này bằng màu đen, chữ trắng
    ST7789_DrawFilledRectangle(0, y_pos, ST7789_WIDTH, 20, BLACK);
    ST7789_WriteString(18, y_pos, file_list[index], Font_11x18, WHITE, BLACK);
}


}

// --- HÀM VẼ DANH SÁCH FILE LÊN LCD ---
static void Draw_FileList(UI_Refresh_Mode_t mode)
{
// 1. Nếu chỉ cần cập nhật con trỏ, ta vẽ lại đúng 2 dòng và thoát luôn (RẤT NHANH)
if (mode == UI_REFRESH_CURSOR)
{
Draw_ListItem(prev_cursor_pos, 0); // Bỏ highlight dòng cũ
Draw_ListItem(cursor_pos, 1);      // Highlight dòng mới
return;
}

// 2. Nếu là REFRESH_FULL (Load lại trang), xóa toàn màn hình
ST7789_Fill_Color(BLACK); 

// Vẽ Header
ST7789_DrawFilledRectangle(0, 0, ST7789_WIDTH, 20, BLUE);
ST7789_WriteString(5, 2, "SD CARD FILES", Font_11x18, WHITE, BLUE);
ST7789_DrawLine(0, 21, ST7789_WIDTH, 21, YELLOW);

if (scan_error_code != FR_OK) {
    char err_str[20];
    sprintf(err_str, "FatFs ERR: %d", scan_error_code);
    ST7789_WriteString(10, 40, "Open Dir Failed!", Font_11x18, RED, BLACK);
    ST7789_WriteString(10, 65, err_str, Font_11x18, YELLOW, BLACK);
    return;
}

if (total_files == 0) {
    ST7789_WriteString(10, 40, "No files found!", Font_11x18, RED, BLACK);
    return;
}

// Lặp để in các file của trang hiện tại
uint16_t start_index = (cursor_pos / MAX_LINES_PER_PAGE) * MAX_LINES_PER_PAGE;
for (uint16_t i = 0; i < MAX_LINES_PER_PAGE; i++) 
{
    uint16_t list_index = start_index + i;
    if (list_index >= total_files) break; 
    
    Draw_ListItem(list_index, (list_index == cursor_pos));
}


}

// --- HÀM VẼ NỘI DUNG FILE ĐƯỢC CHỌN ---
static void Draw_FileContent(void)
{
ST7789_Fill_Color(WHITE);

char* filename = file_list[cursor_pos];

ST7789_DrawFilledRectangle(0, 0, ST7789_WIDTH, 20, RED);
ST7789_WriteString(5, 2, filename, Font_11x18, WHITE, RED);

FIL fil;
FRESULT open_res = f_open(&fil, filename, FA_READ);
if (open_res == FR_OK) 
{
    char buffer[MAX_READ_BUFFER];
    UINT bytes_read;
    
    f_read(&fil, buffer, sizeof(buffer) - 1, &bytes_read);
    buffer[bytes_read] = '\0'; 
    f_close(&fil);

    ST7789_WriteString(5, 25, buffer, Font_7x10, BLACK, WHITE);
}
else
{
    char err_str[20];
    sprintf(err_str, "Err Code: %d", open_res);
    ST7789_WriteString(10, 40, "Error opening!", Font_11x18, RED, WHITE);
    ST7789_WriteString(10, 65, err_str, Font_11x18, RED, WHITE);
}


}

// --- HÀM CẬP NHẬT GIAO DIỆN CHÍNH ---
void Browser_DrawUI(UI_Refresh_Mode_t mode)
{
if (current_state == STATE_FILE_LIST) {
Draw_FileList(mode);
}
else if (current_state == STATE_FILE_CONTENT) {
Draw_FileContent();
}
}

// --- HÀM XỬ LÝ NÚT BẤM ---
void Browser_ProcessInput(char key)
{
if (current_state == STATE_FILE_LIST)
{
if (key == KEY_DOWN) {
if (total_files > 0 && cursor_pos < total_files - 1) {
prev_cursor_pos = cursor_pos;
cursor_pos++;

            // Kiểm tra xem có bị chuyển sang trang mới không
            if ((cursor_pos / MAX_LINES_PER_PAGE) != (prev_cursor_pos / MAX_LINES_PER_PAGE)) {
                Browser_DrawUI(UI_REFRESH_FULL); // Sang trang -> Xóa cả màn hình
            } else {
                Browser_DrawUI(UI_REFRESH_CURSOR); // Cùng trang -> Chỉ cập nhật 2 dòng
            }
        }
    }
    else if (key == KEY_UP) {
        if (total_files > 0 && cursor_pos > 0) {
            prev_cursor_pos = cursor_pos;
            cursor_pos--;
            
            // Kiểm tra xem có bị lùi về trang trước không
            if ((cursor_pos / MAX_LINES_PER_PAGE) != (prev_cursor_pos / MAX_LINES_PER_PAGE)) {
                Browser_DrawUI(UI_REFRESH_FULL); 
            } else {
                Browser_DrawUI(UI_REFRESH_CURSOR);
            }
        }
    }
    else if (key == KEY_ENTER) {
        if (total_files > 0) {
            current_state = STATE_FILE_CONTENT;
            Browser_DrawUI(UI_REFRESH_FULL);
        }
    }
}
else if (current_state == STATE_FILE_CONTENT)
{
    if (key == KEY_BACK) {
        current_state = STATE_FILE_LIST;
        Browser_DrawUI(UI_REFRESH_FULL); // Quay lại danh sách -> Phải load full màn
    }
}


}

// --- KHỞI TẠO ---
void Browser_Init(void)
{
Browser_ScanFiles();
Browser_DrawUI(UI_REFRESH_FULL); // Lần đầu bật máy phải vẽ toàn bộ
}