#ifndef __FILE_BROWSER_H
#define __FILE_BROWSER_H

#include "stm32f10x.h"
#include "fatfs.h"
#include "st7789.h"
#include <string.h>
#include "sdcard.h"

// --- CẤU HÌNH GIAO DIỆN ---
#define MAX_FILES_TO_LOAD   50    // Tối đa load 50 file để tiết kiệm RAM
#define MAX_LINES_PER_PAGE  10    // Số lượng file hiển thị trên 1 trang LCD (240x240 / font 18)
#define MAX_READ_BUFFER     256   // Kích thước bộ đệm để đọc nội dung file (byte)

// --- ĐỊNH NGHĨA PHÍM BẤM (Dùng qua UART) ---
#define KEY_UP      'w'
#define KEY_DOWN    's'
#define KEY_ENTER   'e'
#define KEY_BACK    'q'

// --- CÁC TRẠNG THÁI CỦA HỆ THỐNG ---
typedef enum {
STATE_FILE_LIST,     // Đang ở màn hình danh sách file
STATE_FILE_CONTENT   // Đang ở màn hình đọc nội dung file
} UI_State_t;

// --- CHẾ ĐỘ LÀM MỚI MÀN HÌNH (TỐI ƯU HÓA) ---
typedef enum {
UI_REFRESH_FULL,     // Xóa đen toàn bộ và vẽ lại từ đầu (Khi chuyển trang, đổi màn hình)
UI_REFRESH_CURSOR    // Chỉ vẽ đè 2 dòng bị thay đổi (Khi cuộn trong cùng 1 trang)
} UI_Refresh_Mode_t;

// --- NGUYÊN MẪU HÀM ---
void Browser_Init(void);
void Browser_ScanFiles(void);
void Browser_DrawUI(UI_Refresh_Mode_t mode);
void Browser_ProcessInput(char key);

#endif